* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Carlos Dauden <carlos.dauden@tecnativa.com>
* Angel Moya <angel.moya@domatix.com>
* Dave Lasley <dave@laslabs.com>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Miquel Raïch <miquel.raich@eficent.com>
