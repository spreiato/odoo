* Recover states and others functional fields in Contracts.

